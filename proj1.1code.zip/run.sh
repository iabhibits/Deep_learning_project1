python train.py --train_batch_size=32 --num_train_epochs=300 --logging_steps=100 --seed=42 --output_dir='save/' --do_train --do_eval
